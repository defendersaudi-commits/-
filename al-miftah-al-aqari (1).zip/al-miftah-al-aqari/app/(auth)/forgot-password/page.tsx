"use client";

import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function ForgotPasswordPage() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const { error: resetError } = await supabase.auth.resetPasswordForEmail(
      email,
      {
        redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback?next=/reset-password`,
      }
    );

    setLoading(false);
    if (resetError) {
      setError("تعذّر إرسال رابط الاستعادة، حاول مرة أخرى");
      return;
    }
    setSent(true);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
      <div className="auth-card">
        <h1 className="mb-4 text-center text-2xl font-bold text-primary">
          استعادة كلمة المرور
        </h1>

        {sent ? (
          <p className="text-center text-gray-600">
            إذا كان بريدك مسجلاً لدينا، أرسلنا رابط استعادة كلمة المرور إليه.
            تحقق من بريدك الإلكتروني.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="mb-1 block text-sm text-gray-600">
                البريد الإلكتروني
              </label>
              <input
                className="input-field"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            {error && (
              <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
                {error}
              </p>
            )}
            <button className="btn-primary" disabled={loading}>
              {loading ? "جارٍ الإرسال..." : "إرسال رابط الاستعادة"}
            </button>
          </form>
        )}

        <p className="mt-6 text-center text-sm text-gray-600">
          <Link href="/login" className="font-semibold text-primary">
            الرجوع لتسجيل الدخول
          </Link>
        </p>
      </div>
    </main>
  );
}
