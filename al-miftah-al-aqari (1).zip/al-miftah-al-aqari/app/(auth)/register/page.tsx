"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function RegisterPage() {
  const router = useRouter();
  const supabase = createClient();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    if (password !== confirm) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    if (password.length < 8) {
      setError("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
      return;
    }

    setLoading(true);
    // ملاحظة: لا يُرسل أي دور (role) من الواجهة — الحساب الجديد يُنشأ دائمًا
    // بدور "customer" افتراضيًا عبر الخادم (trigger)، ولا يمكن للعميل رفع صلاحياته بنفسه.
    const { error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { name, phone },
        emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback`,
      },
    });
    setLoading(false);

    if (signUpError) {
      setError(translateError(signUpError.message));
      return;
    }
    setDone(true);
  }

  if (done) {
    return (
      <AuthShell>
        <h1 className="mb-4 text-center text-2xl font-bold text-primary">
          تم إنشاء الحساب ✅
        </h1>
        <p className="text-center text-gray-600">
          أرسلنا رابط تأكيد إلى بريدك الإلكتروني. افتح بريدك واضغط على الرابط
          لتفعيل الحساب، ثم سجّل الدخول.
        </p>
        <Link href="/login" className="btn-primary mt-6 block text-center">
          الذهاب لتسجيل الدخول
        </Link>
      </AuthShell>
    );
  }

  return (
    <AuthShell>
      <h1 className="mb-6 text-center text-2xl font-bold text-primary">
        إنشاء حساب جديد
      </h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="mb-1 block text-sm text-gray-600">الاسم الكامل</label>
          <input
            className="input-field"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">رقم الجوال</label>
          <input
            className="input-field"
            type="tel"
            placeholder="05xxxxxxxx"
            required
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">البريد الإلكتروني</label>
          <input
            className="input-field"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">كلمة المرور</label>
          <input
            className="input-field"
            type="password"
            required
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">تأكيد كلمة المرور</label>
          <input
            className="input-field"
            type="password"
            required
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
          />
        </div>

        {error && (
          <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
            {error}
          </p>
        )}

        <button className="btn-primary" disabled={loading}>
          {loading ? "جارٍ الإنشاء..." : "إنشاء الحساب"}
        </button>
      </form>

      <p className="mt-6 text-center text-sm text-gray-600">
        لديك حساب بالفعل؟{" "}
        <Link href="/login" className="font-semibold text-primary">
          سجّل الدخول
        </Link>
      </p>
    </AuthShell>
  );
}

function AuthShell({ children }: { children: React.ReactNode }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-gray-50 px-4">
      <div className="auth-card">{children}</div>
    </main>
  );
}

function translateError(msg: string) {
  if (msg.includes("already registered") || msg.includes("already exists"))
    return "هذا البريد الإلكتروني مسجّل مسبقًا";
  if (msg.includes("Password"))
    return "كلمة المرور لا تحقق الشروط المطلوبة";
  return "حدث خطأ، حاول مرة أخرى: " + msg;
}
