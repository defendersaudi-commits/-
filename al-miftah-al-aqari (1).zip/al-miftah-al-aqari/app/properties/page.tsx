import { createClient } from "@/lib/supabase/server";
import { PropertyWithImages } from "@/lib/types";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import PropertyCard from "@/components/PropertyCard";
import PropertyFilters from "@/components/PropertyFilters";

export const metadata = {
  title: "تصفح العقارات | المفتاح العقاري",
  description: "ابحث وصفِّ بين مئات العقارات للبيع والإيجار: فلل، شقق، أراضٍ، وعقارات تجارية في جميع مدن المملكة.",
};

interface SearchParams {
  q?: string;
  city?: string;
  district?: string;
  property_type?: string;
  transaction_type?: string;
  min_price?: string;
  max_price?: string;
  min_area?: string;
  bedrooms?: string;
  bathrooms?: string;
  sort?: string;
}

export default async function PropertiesPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const supabase = createClient();

  let query = supabase.from("properties").select("*, property_images(*)");

  if (searchParams.q) {
    query = query.or(
      `title.ilike.%${searchParams.q}%,description.ilike.%${searchParams.q}%`
    );
  }
  if (searchParams.city) query = query.ilike("city", `%${searchParams.city}%`);
  if (searchParams.district) query = query.ilike("district", `%${searchParams.district}%`);
  if (searchParams.property_type) query = query.eq("property_type", searchParams.property_type);
  if (searchParams.transaction_type) query = query.eq("transaction_type", searchParams.transaction_type);
  if (searchParams.min_price) query = query.gte("price", Number(searchParams.min_price));
  if (searchParams.max_price) query = query.lte("price", Number(searchParams.max_price));
  if (searchParams.min_area) query = query.gte("area", Number(searchParams.min_area));
  if (searchParams.bedrooms) query = query.gte("bedrooms", Number(searchParams.bedrooms));
  if (searchParams.bathrooms) query = query.gte("bathrooms", Number(searchParams.bathrooms));

  switch (searchParams.sort) {
    case "price_asc":
      query = query.order("price", { ascending: true });
      break;
    case "price_desc":
      query = query.order("price", { ascending: false });
      break;
    case "featured":
      query = query.order("featured", { ascending: false }).order("created_at", { ascending: false });
      break;
    default:
      query = query.order("created_at", { ascending: false });
  }

  const { data: properties, error } = await query;

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        <h1 className="mb-6 text-2xl font-bold text-gray-800">تصفح العقارات</h1>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
          <aside className="lg:col-span-1">
            <PropertyFilters />
          </aside>

          <div className="lg:col-span-3">
            <p className="mb-4 text-sm text-gray-500">
              {error ? "حدث خطأ أثناء تحميل النتائج" : `${properties?.length ?? 0} نتيجة`}
            </p>

            {properties && properties.length > 0 ? (
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-3">
                {(properties as PropertyWithImages[]).map((p) => (
                  <PropertyCard key={p.id} property={p} />
                ))}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed bg-white p-10 text-center text-gray-400">
                لا توجد عقارات مطابقة لبحثك. جرّب تعديل الفلاتر.
              </div>
            )}
          </div>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
