import Image from "next/image";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import {
  PropertyWithImages,
  PROPERTY_TYPE_LABELS,
  TRANSACTION_TYPE_LABELS,
  PROPERTY_STATUS_LABELS,
} from "@/lib/types";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import FavoriteButton from "@/components/FavoriteButton";
import InquiryForm from "@/components/InquiryForm";

function formatPrice(price: number) {
  return new Intl.NumberFormat("ar-SA").format(price);
}

export async function generateMetadata({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: property } = await supabase
    .from("properties")
    .select("title, description, city, district, price, property_images(image_url)")
    .eq("id", params.id)
    .single();

  if (!property) return { title: "عقار غير موجود | المفتاح العقاري" };

  const image = (property as any).property_images?.[0]?.image_url;
  const description =
    property.description?.slice(0, 155) ??
    `${property.title} في ${property.city} — ${new Intl.NumberFormat("ar-SA").format(property.price)} ريال`;

  return {
    title: `${property.title} | المفتاح العقاري`,
    description,
    openGraph: {
      title: property.title,
      description,
      images: image ? [image] : [],
    },
  };
}

export default async function PropertyDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const supabase = createClient();

  const { data: property } = await supabase
    .from("properties")
    .select("*, property_images(*)")
    .eq("id", params.id)
    .single();

  if (!property) notFound();

  // زيادة عداد المشاهدات (لا يحتاج انتظار النتيجة)
  supabase
    .rpc("increment_property_views" as never, { p_id: params.id } as never)
    .then(() => {})
    .catch(() => {});

  const p = property as PropertyWithImages;
  const images = p.property_images?.length
    ? [...p.property_images].sort((a, b) => a.sort_order - b.sort_order)
    : [{ image_url: "https://picsum.photos/seed/placeholder/1200/700" } as any];

  const details = [
    { label: "نوع العقار", value: PROPERTY_TYPE_LABELS[p.property_type] },
    { label: "نوع المعاملة", value: TRANSACTION_TYPE_LABELS[p.transaction_type] },
    { label: "المدينة", value: p.city },
    { label: "الحي", value: p.district ?? "—" },
    { label: "المساحة", value: p.area ? `${p.area} م²` : "—" },
    { label: "غرف النوم", value: p.bedrooms ?? "—" },
    { label: "دورات المياه", value: p.bathrooms ?? "—" },
    { label: "الحالة", value: PROPERTY_STATUS_LABELS[p.status] },
  ];

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "RealEstateListing",
    name: p.title,
    description: p.description ?? undefined,
    url: `${process.env.NEXT_PUBLIC_SITE_URL ?? ""}/properties/${p.id}`,
    image: images.map((i) => i.image_url),
    offers: {
      "@type": "Offer",
      price: p.price,
      priceCurrency: "SAR",
      availability: p.status === "available" ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
    address: {
      "@type": "PostalAddress",
      addressLocality: p.city,
      addressRegion: p.district ?? undefined,
      addressCountry: "SA",
    },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        {/* Image gallery */}
        <div className="mb-8 grid grid-cols-1 gap-2 sm:grid-cols-4">
          <div className="relative col-span-1 h-72 overflow-hidden rounded-2xl bg-gray-100 sm:col-span-3 sm:h-96">
            <Image src={images[0].image_url} alt={p.title} fill className="object-cover" unoptimized />
          </div>
          <div className="grid grid-cols-4 gap-2 sm:grid-cols-1">
            {images.slice(1, 5).map((img, i) => (
              <div key={i} className="relative h-16 overflow-hidden rounded-lg bg-gray-100 sm:h-[5.5rem]">
                <Image src={img.image_url} alt="" fill className="object-cover" unoptimized />
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="mb-4 flex items-start justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-800">{p.title}</h1>
                <p className="text-gray-500">
                  {p.city}
                  {p.district ? ` · ${p.district}` : ""}
                  {p.address ? ` · ${p.address}` : ""}
                </p>
              </div>
              <FavoriteButton propertyId={p.id} />
            </div>

            <p className="mb-6 text-2xl font-bold text-primary">
              {formatPrice(p.price)} ريال
              {p.transaction_type === "rent" && (
                <span className="text-sm font-normal text-gray-400"> / سنويًا</span>
              )}
            </p>

            <div className="mb-8 grid grid-cols-2 gap-4 rounded-2xl border bg-white p-5 sm:grid-cols-4">
              {details.map((d) => (
                <div key={d.label}>
                  <p className="text-xs text-gray-400">{d.label}</p>
                  <p className="font-semibold text-gray-700">{d.value}</p>
                </div>
              ))}
            </div>

            {p.description && (
              <div className="mb-8">
                <h2 className="mb-2 font-bold text-gray-800">وصف العقار</h2>
                <p className="whitespace-pre-line leading-7 text-gray-600">{p.description}</p>
              </div>
            )}

            {p.latitude && p.longitude && (
              <div className="mb-8">
                <h2 className="mb-2 font-bold text-gray-800">الموقع</h2>
                <a
                  href={`https://www.google.com/maps?q=${p.latitude},${p.longitude}`}
                  target="_blank"
                  className="text-sm font-semibold text-primary hover:underline"
                >
                  عرض الموقع على خرائط جوجل ←
                </a>
              </div>
            )}
          </div>

          <div className="space-y-6">
            <InquiryForm propertyId={p.id} />
            <div className="rounded-2xl border bg-white p-5 text-center">
              <p className="mb-2 text-sm text-gray-500">أو تواصل معنا مباشرة</p>
              <a href="tel:0556407465" className="btn-primary mb-2 block" dir="ltr">
                📞 0556407465
              </a>
              <a
                href="mailto:defendersaudi@gmail.com"
                className="block rounded-lg border px-4 py-2.5 text-sm font-semibold text-gray-600 hover:bg-gray-50"
              >
                ✉️ defendersaudi@gmail.com
              </a>
            </div>
          </div>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
