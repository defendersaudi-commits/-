import type { Metadata } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-cairo",
});

export const metadata: Metadata = {
  title: "المفتاح العقاري | منصتك للبحث عن العقار المناسب",
  description:
    "المفتاح العقاري — منصة عقارية سعودية لبيع وشراء وتأجير الفلل والشقق والأراضي والعقارات التجارية.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable}>
      <body className="font-sans">{children}</body>
    </html>
  );
}
