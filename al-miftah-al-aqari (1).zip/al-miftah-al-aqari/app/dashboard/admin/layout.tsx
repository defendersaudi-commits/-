import { redirect } from "next/navigation";
import { getCurrentProfile } from "@/lib/supabase/server";
import LogoutButton from "@/components/LogoutButton";
import Link from "next/link";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // فحص ثانٍ على مستوى الخادم (Defense in depth) — لا نعتمد فقط على الـ middleware
  const profile = await getCurrentProfile();
  if (!profile || (profile.role !== "owner" && profile.role !== "admin")) {
    redirect("/unauthorized");
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="flex items-center justify-between border-b bg-primary px-6 py-4 text-white shadow-sm">
        <div className="flex items-center gap-6">
          <Link href="/" className="text-lg font-bold">
            المفتاح العقاري — لوحة الإدارة
          </Link>
          <nav className="hidden gap-4 text-sm sm:flex">
            <Link href="/dashboard/admin" className="hover:underline">
              الإحصائيات
            </Link>
            <Link href="/dashboard/admin/properties" className="hover:underline">
              العقارات
            </Link>
            <Link href="/dashboard/admin/customers" className="hover:underline">
              العملاء
            </Link>
            <Link href="/dashboard/admin/requests" className="hover:underline">
              الطلبات
            </Link>
            <Link href="/dashboard/admin/messages" className="hover:underline">
              الرسائل
            </Link>
            <Link href="/dashboard/admin/activity-log" className="hover:underline">
              سجل النشاط
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <span className="rounded-full bg-white/20 px-3 py-1 text-xs">
            {profile.role === "owner" ? "المالك" : "مدير"}: {profile.name}
          </span>
          <LogoutButton />
        </div>
      </header>
      <div className="mx-auto max-w-6xl px-6 py-8">{children}</div>
    </div>
  );
}
