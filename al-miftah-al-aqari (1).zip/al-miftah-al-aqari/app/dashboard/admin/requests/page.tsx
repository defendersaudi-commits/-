import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import type { PropertyRequest } from "@/lib/types";

const STATUS_LABELS: Record<string, string> = {
  new: "جديد",
  in_review: "قيد المراجعة",
  contacted: "تم التواصل",
  completed: "مكتمل",
  closed: "مغلق",
};

const STATUS_STYLES: Record<string, string> = {
  new: "bg-blue-100 text-blue-700",
  in_review: "bg-amber-100 text-amber-700",
  contacted: "bg-purple-100 text-purple-700",
  completed: "bg-green-100 text-green-700",
  closed: "bg-gray-200 text-gray-600",
};

export default async function AdminRequestsPage() {
  const supabase = createClient();
  const { data: requests } = await supabase
    .from("requests")
    .select("*, profiles(name, phone, email)")
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">إدارة الطلبات العقارية</h1>

      <div className="space-y-3">
        {(requests as any[] | null)?.map((r) => (
          <Link
            key={r.id}
            href={`/dashboard/admin/requests/${r.id}`}
            className="flex flex-col justify-between gap-2 rounded-2xl border bg-white p-4 hover:shadow-sm sm:flex-row sm:items-center"
          >
            <div>
              <p className="font-semibold text-gray-800">
                {r.request_type} — {r.profiles?.name ?? "غير معروف"}
              </p>
              <p className="text-sm text-gray-500">
                {r.city ?? "—"} {r.district ? `· ${r.district}` : ""} ·{" "}
                {r.budget ? new Intl.NumberFormat("ar-SA").format(r.budget) + " ريال" : "بدون ميزانية محددة"}
              </p>
            </div>
            <span className={`w-fit rounded-full px-3 py-1 text-xs font-semibold ${STATUS_STYLES[r.status]}`}>
              {STATUS_LABELS[r.status]}
            </span>
          </Link>
        ))}
        {(!requests || requests.length === 0) && (
          <p className="rounded-2xl border border-dashed bg-white p-8 text-center text-gray-400">
            لا توجد طلبات حتى الآن.
          </p>
        )}
      </div>
    </div>
  );
}
