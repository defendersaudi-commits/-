import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import RequestControls from "@/components/admin/RequestControls";
import { PROPERTY_TYPE_LABELS } from "@/lib/types";

export default async function AdminRequestDetailPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: request } = await supabase
    .from("requests")
    .select("*, profiles(name, phone, email)")
    .eq("id", params.id)
    .single();

  if (!request) notFound();
  const r = request as any;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">تفاصيل الطلب</h1>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="space-y-3 rounded-2xl border bg-white p-6">
          <h2 className="font-bold text-gray-800">بيانات مقدّم الطلب</h2>
          <p className="text-sm text-gray-600">الاسم: {r.profiles?.name ?? "—"}</p>
          <p className="text-sm text-gray-600">الجوال: {r.profiles?.phone ?? "—"}</p>
          <p className="text-sm text-gray-600">البريد: {r.profiles?.email ?? "—"}</p>

          <h2 className="pt-4 font-bold text-gray-800">تفاصيل الطلب</h2>
          <p className="text-sm text-gray-600">نوع الطلب: {r.request_type}</p>
          <p className="text-sm text-gray-600">
            نوع العقار: {r.property_type ? PROPERTY_TYPE_LABELS[r.property_type as keyof typeof PROPERTY_TYPE_LABELS] : "—"}
          </p>
          <p className="text-sm text-gray-600">المدينة: {r.city ?? "—"} {r.district ? `· ${r.district}` : ""}</p>
          <p className="text-sm text-gray-600">
            الميزانية: {r.budget ? new Intl.NumberFormat("ar-SA").format(r.budget) + " ريال" : "غير محددة"}
          </p>
          <p className="text-sm text-gray-600">التفاصيل: {r.details ?? "—"}</p>
        </div>

        <RequestControls requestId={r.id} currentStatus={r.status} currentNotes={r.admin_notes ?? ""} />
      </div>
    </div>
  );
}
