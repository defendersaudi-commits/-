import { createProperty } from "@/lib/actions/properties";
import PropertyFormFields from "@/components/PropertyFormFields";

export default function NewPropertyPage() {
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">إضافة عقار جديد</h1>
      <form action={createProperty} className="max-w-3xl space-y-6 rounded-2xl border bg-white p-6">
        <PropertyFormFields />
        <button type="submit" className="btn-primary max-w-xs">
          حفظ ومتابعة لإضافة الصور
        </button>
      </form>
    </div>
  );
}
