import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { updateProperty } from "@/lib/actions/properties";
import PropertyFormFields from "@/components/PropertyFormFields";
import PropertyImageManager from "@/components/PropertyImageManager";
import type { Property, PropertyImage } from "@/lib/types";

export default async function EditPropertyPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const { data: property } = await supabase
    .from("properties")
    .select("*, property_images(*)")
    .eq("id", params.id)
    .single();

  if (!property) notFound();

  const updateWithId = updateProperty.bind(null, params.id);

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">تعديل العقار</h1>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <form action={updateWithId} className="space-y-6 rounded-2xl border bg-white p-6 lg:col-span-2">
          <PropertyFormFields property={property as Property} />
          <button type="submit" className="btn-primary max-w-xs">حفظ التعديلات</button>
        </form>

        <div>
          <PropertyImageManager
            propertyId={params.id}
            images={(property.property_images as PropertyImage[]) ?? []}
          />
        </div>
      </div>
    </div>
  );
}
