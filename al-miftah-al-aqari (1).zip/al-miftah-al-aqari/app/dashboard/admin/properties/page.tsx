import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { PROPERTY_STATUS_LABELS, PROPERTY_TYPE_LABELS, Property } from "@/lib/types";
import PropertyRowActions from "@/components/admin/PropertyRowActions";

export default async function AdminPropertiesPage() {
  const supabase = createClient();
  const { data: properties } = await supabase
    .from("properties")
    .select("*")
    .order("created_at", { ascending: false });

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">إدارة العقارات</h1>
        <Link href="/dashboard/admin/properties/new" className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white hover:bg-primary-dark">
          + إضافة عقار جديد
        </Link>
      </div>

      <div className="overflow-x-auto rounded-2xl border bg-white">
        <table className="w-full min-w-[800px] text-right text-sm">
          <thead className="bg-gray-50 text-xs text-gray-500">
            <tr>
              <th className="px-4 py-3">العنوان</th>
              <th className="px-4 py-3">النوع</th>
              <th className="px-4 py-3">المدينة</th>
              <th className="px-4 py-3">السعر</th>
              <th className="px-4 py-3">مشاهدات</th>
              <th className="px-4 py-3">مفضلة</th>
              <th className="px-4 py-3">إجراءات</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {(properties as Property[] | null)?.map((p) => (
              <tr key={p.id} className="border-t">
                <td className="px-4 py-3 font-semibold text-gray-800">{p.title}</td>
                <td className="px-4 py-3 text-gray-500">{PROPERTY_TYPE_LABELS[p.property_type]}</td>
                <td className="px-4 py-3 text-gray-500">{p.city}</td>
                <td className="px-4 py-3 text-gray-500">{new Intl.NumberFormat("ar-SA").format(p.price)}</td>
                <td className="px-4 py-3 text-gray-500">{p.views_count}</td>
                <td className="px-4 py-3 text-gray-500">{p.favorites_count}</td>
                <td className="px-4 py-3"><PropertyRowActions property={p} /></td>
                <td className="px-4 py-3">
                  <Link href={`/dashboard/admin/properties/${p.id}/edit`} className="font-semibold text-primary hover:underline">
                    تعديل
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {(!properties || properties.length === 0) && (
          <p className="p-8 text-center text-gray-400">لا توجد عقارات بعد.</p>
        )}
      </div>
    </div>
  );
}
