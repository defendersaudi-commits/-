import { createClient } from "@/lib/supabase/server";
import InquiryReplyBox from "@/components/admin/InquiryReplyBox";

export default async function AdminMessagesPage() {
  const supabase = createClient();

  const { data: inquiries } = await supabase
    .from("inquiries")
    .select("*, properties(title)")
    .order("created_at", { ascending: false })
    .limit(50);

  const { data: directMessages } = await supabase
    .from("messages")
    .select("*, sender:profiles!messages_sender_id_fkey(name, role)")
    .order("created_at", { ascending: false })
    .limit(50);

  return (
    <div className="space-y-10">
      <div>
        <h1 className="mb-6 text-2xl font-bold text-gray-800">استفسارات العقارات</h1>
        <div className="space-y-4">
          {(inquiries as any[] | null)?.map((i) => (
            <div key={i.id} className="rounded-2xl border bg-white p-5">
              <div className="mb-2 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-gray-800">{i.name} — {i.phone}</p>
                  <p className="text-xs text-gray-400">
                    {i.properties?.title ? `عن: ${i.properties.title}` : "استفسار عام"} · {new Date(i.created_at).toLocaleDateString("ar-SA")}
                  </p>
                </div>
                <span className="rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-500">{i.status}</span>
              </div>
              <p className="mb-3 text-sm text-gray-600">{i.message}</p>
              <InquiryReplyBox inquiryId={i.id} existingReply={i.admin_reply} />
            </div>
          ))}
          {(!inquiries || inquiries.length === 0) && (
            <p className="rounded-2xl border border-dashed bg-white p-8 text-center text-gray-400">لا توجد استفسارات.</p>
          )}
        </div>
      </div>

      <div>
        <h2 className="mb-6 text-2xl font-bold text-gray-800">الرسائل المباشرة من العملاء</h2>
        <div className="space-y-3">
          {(directMessages as any[] | null)
            ?.filter((m) => m.sender?.role === "customer")
            .map((m) => (
              <div key={m.id} className="rounded-2xl border bg-white p-4">
                <p className="text-sm font-semibold text-gray-800">{m.sender?.name}</p>
                <p className="text-xs text-gray-400">{m.subject}</p>
                <p className="mt-1 text-sm text-gray-600">{m.message}</p>
              </div>
            ))}
          {(!directMessages || directMessages.length === 0) && (
            <p className="rounded-2xl border border-dashed bg-white p-8 text-center text-gray-400">لا توجد رسائل.</p>
          )}
        </div>
      </div>
    </div>
  );
}
