import { createClient } from "@/lib/supabase/server";
import Link from "next/link";

export default async function AdminDashboardPage() {
  const supabase = createClient();

  const [
    { count: totalProperties },
    { count: availableProperties },
    { count: soldProperties },
    { count: rentedProperties },
    { count: totalCustomers },
    { count: newCustomers },
    { count: newRequests },
    { count: processingRequests },
    { count: totalInquiries },
    { data: mostViewed },
    { data: mostFavorited },
  ] = await Promise.all([
    supabase.from("properties").select("*", { count: "exact", head: true }),
    supabase.from("properties").select("*", { count: "exact", head: true }).eq("status", "available"),
    supabase.from("properties").select("*", { count: "exact", head: true }).eq("status", "sold"),
    supabase.from("properties").select("*", { count: "exact", head: true }).eq("status", "rented"),
    supabase.from("profiles").select("*", { count: "exact", head: true }).eq("role", "customer"),
    supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })
      .eq("role", "customer")
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()),
    supabase.from("requests").select("*", { count: "exact", head: true }).eq("status", "new"),
    supabase.from("requests").select("*", { count: "exact", head: true }).in("status", ["in_review", "contacted"]),
    supabase.from("inquiries").select("*", { count: "exact", head: true }),
    supabase.from("properties").select("id, title, views_count").order("views_count", { ascending: false }).limit(5),
    supabase.from("properties").select("id, title, favorites_count").order("favorites_count", { ascending: false }).limit(5),
  ]);

  const statCards = [
    { label: "إجمالي العقارات", value: totalProperties ?? 0, href: "/dashboard/admin/properties" },
    { label: "العقارات المتاحة", value: availableProperties ?? 0 },
    { label: "العقارات المباعة", value: soldProperties ?? 0 },
    { label: "العقارات المؤجرة", value: rentedProperties ?? 0 },
    { label: "إجمالي العملاء", value: totalCustomers ?? 0, href: "/dashboard/admin/customers" },
    { label: "عملاء جدد (٣٠ يوم)", value: newCustomers ?? 0 },
    { label: "طلبات جديدة", value: newRequests ?? 0, href: "/dashboard/admin/requests" },
    { label: "طلبات قيد المعالجة", value: processingRequests ?? 0 },
    { label: "عدد الاستفسارات", value: totalInquiries ?? 0, href: "/dashboard/admin/messages" },
  ];

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">نظرة عامة على المنصة</h1>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-3">
        {statCards.map((s) => {
          const Card = (
            <div className="rounded-xl bg-white p-6 shadow-sm transition hover:shadow-md">
              <p className="text-sm text-gray-500">{s.label}</p>
              <p className="mt-2 text-3xl font-bold text-primary">{s.value}</p>
            </div>
          );
          return s.href ? (
            <Link key={s.label} href={s.href}>{Card}</Link>
          ) : (
            <div key={s.label}>{Card}</div>
          );
        })}
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border bg-white p-6">
          <h2 className="mb-4 font-bold text-gray-800">الأكثر مشاهدة</h2>
          <ul className="space-y-3">
            {mostViewed?.map((p) => (
              <li key={p.id} className="flex items-center justify-between text-sm">
                <Link href={`/dashboard/admin/properties/${p.id}/edit`} className="text-gray-700 hover:text-primary">
                  {p.title}
                </Link>
                <span className="font-semibold text-primary">{p.views_count} مشاهدة</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-2xl border bg-white p-6">
          <h2 className="mb-4 font-bold text-gray-800">الأكثر حفظًا في المفضلة</h2>
          <ul className="space-y-3">
            {mostFavorited?.map((p) => (
              <li key={p.id} className="flex items-center justify-between text-sm">
                <Link href={`/dashboard/admin/properties/${p.id}/edit`} className="text-gray-700 hover:text-primary">
                  {p.title}
                </Link>
                <span className="font-semibold text-primary">{p.favorites_count} حفظ</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
