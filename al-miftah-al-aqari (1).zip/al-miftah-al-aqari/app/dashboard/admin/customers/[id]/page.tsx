import { notFound } from "next/navigation";
import { createClient, getCurrentProfile } from "@/lib/supabase/server";
import { updateCustomerInfo } from "@/lib/actions/customers";
import CustomerActions from "@/components/admin/CustomerActions";
import type { Profile, PropertyRequest, Inquiry } from "@/lib/types";

export default async function AdminCustomerDetailPage({ params }: { params: { id: string } }) {
  const supabase = createClient();
  const viewer = await getCurrentProfile();

  const { data: customer } = await supabase.from("profiles").select("*").eq("id", params.id).single();
  if (!customer) notFound();

  const { data: requests } = await supabase
    .from("requests")
    .select("*")
    .eq("user_id", params.id)
    .order("created_at", { ascending: false });

  const { data: inquiries } = await supabase
    .from("inquiries")
    .select("*")
    .eq("user_id", params.id)
    .order("created_at", { ascending: false });

  const updateWithId = updateCustomerInfo.bind(null, params.id);
  const c = customer as Profile;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-800">تفاصيل العميل</h1>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <form action={updateWithId} className="space-y-4 rounded-2xl border bg-white p-6 lg:col-span-2">
          <div>
            <label className="mb-1 block text-sm text-gray-600">الاسم</label>
            <input name="name" defaultValue={c.name} className="input-field" />
          </div>
          <div>
            <label className="mb-1 block text-sm text-gray-600">البريد الإلكتروني</label>
            <input value={c.email} disabled className="input-field bg-gray-50 text-gray-400" />
          </div>
          <div>
            <label className="mb-1 block text-sm text-gray-600">رقم الجوال</label>
            <input name="phone" defaultValue={c.phone ?? ""} className="input-field" />
          </div>
          <button type="submit" className="btn-primary max-w-xs">حفظ التعديلات</button>
        </form>

        <div className="rounded-2xl border bg-white p-6">
          <p className="mb-1 text-xs text-gray-400">الحالة الحالية</p>
          <p className="mb-4 font-semibold text-gray-800">
            {c.role === "owner" ? "المالك" : c.role === "admin" ? "مدير" : "عميل"} ·{" "}
            {c.status === "active" ? "نشط" : "معطّل"}
          </p>
          <CustomerActions customer={c} isOwnerViewing={viewer?.role === "owner"} />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border bg-white p-6">
          <h2 className="mb-3 font-bold text-gray-800">طلبات العميل ({requests?.length ?? 0})</h2>
          <ul className="space-y-2 text-sm">
            {(requests as PropertyRequest[] | null)?.map((r) => (
              <li key={r.id} className="border-b pb-2 last:border-0">
                <p className="font-semibold text-gray-700">{r.request_type}</p>
                <p className="text-gray-400">{r.city} · الحالة: {r.status}</p>
              </li>
            ))}
            {(!requests || requests.length === 0) && <p className="text-gray-400">لا يوجد طلبات.</p>}
          </ul>
        </div>

        <div className="rounded-2xl border bg-white p-6">
          <h2 className="mb-3 font-bold text-gray-800">استفسارات العميل ({inquiries?.length ?? 0})</h2>
          <ul className="space-y-2 text-sm">
            {(inquiries as Inquiry[] | null)?.map((i) => (
              <li key={i.id} className="border-b pb-2 last:border-0">
                <p className="text-gray-700">{i.message}</p>
                <p className="text-gray-400">الحالة: {i.status}</p>
              </li>
            ))}
            {(!inquiries || inquiries.length === 0) && <p className="text-gray-400">لا يوجد استفسارات.</p>}
          </ul>
        </div>
      </div>
    </div>
  );
}
