import { createClient } from "@/lib/supabase/server";

const ACTION_LABELS: Record<string, string> = {
  create_property: "إضافة عقار",
  update_property: "تعديل عقار",
  delete_property: "حذف عقار",
  toggle_featured: "تغيير حالة التميّز",
  change_property_status: "تغيير حالة عقار",
  update_customer_status: "تغيير حالة عميل",
  update_customer_info: "تعديل بيانات عميل",
  delete_customer: "حذف عميل",
  set_user_role: "تغيير دور مستخدم",
  update_request_status: "تغيير حالة طلب",
  archive_request: "أرشفة طلب",
  reply_to_inquiry: "الرد على استفسار",
  update_inquiry_status: "تغيير حالة استفسار",
  send_message: "إرسال رسالة",
};

export default async function AdminActivityLogPage() {
  const supabase = createClient();
  const { data: logs } = await supabase
    .from("admin_activity_log")
    .select("*, profiles(name)")
    .order("created_at", { ascending: false })
    .limit(100);

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">سجل نشاط الإدارة</h1>
      <div className="overflow-hidden rounded-2xl border bg-white">
        <table className="w-full text-right text-sm">
          <thead className="bg-gray-50 text-xs text-gray-500">
            <tr>
              <th className="px-4 py-3">التاريخ</th>
              <th className="px-4 py-3">المنفّذ</th>
              <th className="px-4 py-3">الإجراء</th>
              <th className="px-4 py-3">التفاصيل</th>
            </tr>
          </thead>
          <tbody>
            {(logs as any[] | null)?.map((l) => (
              <tr key={l.id} className="border-t">
                <td className="px-4 py-3 text-gray-500">{new Date(l.created_at).toLocaleString("ar-SA")}</td>
                <td className="px-4 py-3 text-gray-700">{l.profiles?.name ?? "—"}</td>
                <td className="px-4 py-3 font-semibold text-gray-800">{ACTION_LABELS[l.action] ?? l.action}</td>
                <td className="px-4 py-3 text-xs text-gray-400">{JSON.stringify(l.details)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {(!logs || logs.length === 0) && <p className="p-8 text-center text-gray-400">لا يوجد نشاط مسجّل بعد.</p>}
      </div>
    </div>
  );
}
