import Link from "next/link";
import { createClient, getCurrentProfile } from "@/lib/supabase/server";
import type { PropertyRequest } from "@/lib/types";

const STATUS_LABELS: Record<string, string> = {
  new: "جديد",
  in_review: "قيد المراجعة",
  contacted: "تم التواصل",
  completed: "مكتمل",
  closed: "مغلق",
};

export default async function CustomerRequestsPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: requests } = await supabase
    .from("requests")
    .select("*")
    .eq("user_id", profile?.id)
    .order("created_at", { ascending: false });

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">طلباتي</h1>
        <Link href="/dashboard/customer/requests/new" className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white">
          + طلب جديد
        </Link>
      </div>

      <div className="space-y-3">
        {(requests as PropertyRequest[] | null)?.map((r) => (
          <div key={r.id} className="flex items-center justify-between rounded-2xl border bg-white p-4">
            <div>
              <p className="font-semibold text-gray-800">{r.request_type}</p>
              <p className="text-sm text-gray-500">{r.city ?? "—"} {r.district ? `· ${r.district}` : ""}</p>
            </div>
            <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-600">
              {STATUS_LABELS[r.status]}
            </span>
          </div>
        ))}
        {(!requests || requests.length === 0) && (
          <p className="rounded-2xl border border-dashed bg-white p-10 text-center text-gray-400">
            لم ترسل أي طلب عقاري بعد.
          </p>
        )}
      </div>
    </div>
  );
}
