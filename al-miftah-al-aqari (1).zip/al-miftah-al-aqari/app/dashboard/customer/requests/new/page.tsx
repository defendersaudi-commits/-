import { redirect } from "next/navigation";
import { createPropertyRequest } from "@/lib/actions/customer";

async function submitAndRedirect(formData: FormData) {
  "use server";
  await createPropertyRequest(formData);
  redirect("/dashboard/customer/requests");
}

export default function NewRequestPage() {
  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">إرسال طلب عقاري</h1>
      <form action={submitAndRedirect} className="max-w-2xl space-y-4 rounded-2xl border bg-white p-6">
        <div>
          <label className="mb-1 block text-sm text-gray-600">نوع الطلب *</label>
          <select name="request_type" required className="input-field">
            <option value="أرغب بالشراء">أرغب بالشراء</option>
            <option value="أرغب بالاستئجار">أرغب بالاستئجار</option>
            <option value="أرغب ببيع عقاري">أرغب ببيع عقاري</option>
            <option value="أرغب بتأجير عقاري">أرغب بتأجير عقاري</option>
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">نوع العقار</label>
          <select name="property_type" className="input-field">
            <option value="">غير محدد</option>
            <option value="villa">فيلا</option>
            <option value="apartment">شقة</option>
            <option value="land">أرض</option>
            <option value="building">عمارة</option>
            <option value="commercial">تجاري</option>
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="mb-1 block text-sm text-gray-600">المدينة</label>
            <input name="city" className="input-field" />
          </div>
          <div>
            <label className="mb-1 block text-sm text-gray-600">الحي</label>
            <input name="district" className="input-field" />
          </div>
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">الميزانية التقريبية (ريال)</label>
          <input type="number" name="budget" className="input-field" />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">تفاصيل إضافية</label>
          <textarea name="details" rows={4} className="input-field" />
        </div>
        <button type="submit" className="btn-primary max-w-xs">إرسال الطلب</button>
      </form>
    </div>
  );
}
