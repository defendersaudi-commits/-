import { getCurrentProfile } from "@/lib/supabase/server";
import LogoutButton from "@/components/LogoutButton";
import Link from "next/link";

const NAV = [
  { href: "/dashboard/customer", label: "الرئيسية" },
  { href: "/dashboard/customer/profile", label: "الملف الشخصي" },
  { href: "/dashboard/customer/favorites", label: "المفضلة" },
  { href: "/dashboard/customer/requests", label: "طلباتي" },
  { href: "/dashboard/customer/inquiries", label: "استفساراتي" },
  { href: "/dashboard/customer/messages", label: "الرسائل" },
  { href: "/dashboard/customer/notifications", label: "الإشعارات" },
];

export default async function CustomerLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const profile = await getCurrentProfile();

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="flex items-center justify-between border-b bg-white px-6 py-4 shadow-sm">
        <Link href="/" className="text-lg font-bold text-primary">
          المفتاح العقاري
        </Link>
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-600">
            مرحبًا، {profile?.name}
          </span>
          <LogoutButton />
        </div>
      </header>
      <div className="mx-auto flex max-w-6xl gap-6 px-6 py-8">
        <nav className="hidden w-48 shrink-0 space-y-1 sm:block">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="block rounded-lg px-3 py-2 text-sm font-medium text-gray-600 hover:bg-white hover:text-primary"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="min-w-0 flex-1">{children}</div>
      </div>
    </div>
  );
}
