import { createClient, getCurrentProfile } from "@/lib/supabase/server";
import PropertyCard from "@/components/PropertyCard";
import type { PropertyWithImages } from "@/lib/types";

export default async function CustomerFavoritesPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: favorites } = await supabase
    .from("favorites")
    .select("property:properties(*, property_images(*))")
    .eq("user_id", profile?.id);

  const properties = (favorites as any[] | null)?.map((f) => f.property).filter(Boolean) as
    | PropertyWithImages[]
    | undefined;

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">العقارات المفضلة</h1>
      {properties && properties.length > 0 ? (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {properties.map((p) => <PropertyCard key={p.id} property={p} />)}
        </div>
      ) : (
        <p className="rounded-2xl border border-dashed bg-white p-10 text-center text-gray-400">
          لم تضف أي عقار للمفضلة بعد.
        </p>
      )}
    </div>
  );
}
