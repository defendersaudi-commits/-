import { createClient, getCurrentProfile } from "@/lib/supabase/server";
import { markAllNotificationsRead } from "@/lib/actions/customer";

export default async function CustomerNotificationsPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: notifications } = await supabase
    .from("notifications")
    .select("*")
    .eq("user_id", profile?.id)
    .order("created_at", { ascending: false });

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">الإشعارات</h1>
        <form action={markAllNotificationsRead}>
          <button className="text-sm font-semibold text-primary">تحديد الكل كمقروء</button>
        </form>
      </div>

      <div className="space-y-2">
        {notifications?.map((n) => (
          <div
            key={n.id}
            className={`rounded-xl border p-4 ${n.is_read ? "bg-white" : "border-primary/30 bg-primary/5"}`}
          >
            <div className="flex items-center justify-between">
              <p className="font-semibold text-gray-800">{n.title}</p>
              <span className="text-xs text-gray-400">{new Date(n.created_at).toLocaleDateString("ar-SA")}</span>
            </div>
            {n.message && <p className="mt-1 text-sm text-gray-600">{n.message}</p>}
          </div>
        ))}
        {(!notifications || notifications.length === 0) && (
          <p className="rounded-2xl border border-dashed bg-white p-10 text-center text-gray-400">لا توجد إشعارات.</p>
        )}
      </div>
    </div>
  );
}
