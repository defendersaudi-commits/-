import { createClient, getCurrentProfile } from "@/lib/supabase/server";
import NewMessageForm from "@/components/NewMessageForm";

export default async function CustomerMessagesPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: messages } = await supabase
    .from("messages")
    .select("*")
    .or(`sender_id.eq.${profile?.id},receiver_id.eq.${profile?.id}`)
    .order("created_at", { ascending: false });

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div className="space-y-3 lg:col-span-2">
        <h1 className="mb-3 text-2xl font-bold text-gray-800">رسائلي</h1>
        {(messages as any[] | null)?.map((m) => (
          <div
            key={m.id}
            className={`rounded-2xl border p-4 ${m.sender_id === profile?.id ? "bg-primary/5" : "bg-white"}`}
          >
            <p className="mb-1 text-xs text-gray-400">
              {m.sender_id === profile?.id ? "أنت" : "إدارة المنصة"} · {new Date(m.created_at).toLocaleDateString("ar-SA")}
            </p>
            {m.subject && <p className="font-semibold text-gray-800">{m.subject}</p>}
            <p className="text-sm text-gray-600">{m.message}</p>
          </div>
        ))}
        {(!messages || messages.length === 0) && (
          <p className="rounded-2xl border border-dashed bg-white p-10 text-center text-gray-400">لا توجد رسائل بعد.</p>
        )}
      </div>
      <div><NewMessageForm /></div>
    </div>
  );
}
