import { createClient, getCurrentProfile } from "@/lib/supabase/server";

export default async function CustomerInquiriesPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const { data: inquiries } = await supabase
    .from("inquiries")
    .select("*, properties(title)")
    .eq("user_id", profile?.id)
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">استفساراتي</h1>
      <div className="space-y-3">
        {(inquiries as any[] | null)?.map((i) => (
          <div key={i.id} className="rounded-2xl border bg-white p-4">
            <p className="mb-1 text-xs text-gray-400">
              {i.properties?.title ?? "استفسار عام"} · {new Date(i.created_at).toLocaleDateString("ar-SA")}
            </p>
            <p className="mb-2 text-sm text-gray-700">{i.message}</p>
            {i.admin_reply ? (
              <div className="rounded-lg bg-green-50 p-3 text-sm text-green-700">
                <p className="mb-1 font-semibold">الرد:</p>
                <p>{i.admin_reply}</p>
              </div>
            ) : (
              <span className="rounded-full bg-amber-100 px-2 py-1 text-xs font-semibold text-amber-700">
                بانتظار الرد
              </span>
            )}
          </div>
        ))}
        {(!inquiries || inquiries.length === 0) && (
          <p className="rounded-2xl border border-dashed bg-white p-10 text-center text-gray-400">
            لم ترسل أي استفسار بعد.
          </p>
        )}
      </div>
    </div>
  );
}
