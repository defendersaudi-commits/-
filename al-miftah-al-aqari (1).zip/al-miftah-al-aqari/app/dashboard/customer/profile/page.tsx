import { getCurrentProfile } from "@/lib/supabase/server";
import { updateOwnProfile } from "@/lib/actions/customer";
import ChangePasswordForm from "@/components/ChangePasswordForm";

export default async function CustomerProfilePage() {
  const profile = await getCurrentProfile();

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <form action={updateOwnProfile} className="space-y-4 rounded-2xl border bg-white p-6">
        <h2 className="font-bold text-gray-800">الملف الشخصي</h2>
        <div>
          <label className="mb-1 block text-sm text-gray-600">الاسم</label>
          <input name="name" defaultValue={profile?.name} className="input-field" />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">البريد الإلكتروني</label>
          <input value={profile?.email} disabled className="input-field bg-gray-50 text-gray-400" />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">رقم الجوال</label>
          <input name="phone" defaultValue={profile?.phone ?? ""} className="input-field" />
        </div>
        <button type="submit" className="btn-primary">حفظ التعديلات</button>
      </form>

      <ChangePasswordForm />
    </div>
  );
}
