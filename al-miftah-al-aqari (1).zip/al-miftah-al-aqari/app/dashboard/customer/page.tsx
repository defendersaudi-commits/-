import Link from "next/link";
import { createClient, getCurrentProfile } from "@/lib/supabase/server";

export default async function CustomerDashboardPage() {
  const profile = await getCurrentProfile();
  const supabase = createClient();

  const [{ count: favCount }, { count: reqCount }, { count: unreadCount }] = await Promise.all([
    supabase.from("favorites").select("*", { count: "exact", head: true }).eq("user_id", profile?.id),
    supabase.from("requests").select("*", { count: "exact", head: true }).eq("user_id", profile?.id),
    supabase.from("notifications").select("*", { count: "exact", head: true }).eq("user_id", profile?.id).eq("is_read", false),
  ]);

  const cards = [
    { title: "الملف الشخصي", desc: "تعديل بياناتك الشخصية وكلمة المرور", href: "/dashboard/customer/profile" },
    { title: "العقارات المفضلة", desc: `${favCount ?? 0} عقار محفوظ`, href: "/dashboard/customer/favorites" },
    { title: "طلباتي", desc: `${reqCount ?? 0} طلب عقاري`, href: "/dashboard/customer/requests" },
    { title: "استفساراتي", desc: "الاستفسارات التي أرسلتها عن عقارات", href: "/dashboard/customer/inquiries" },
    { title: "الرسائل", desc: "رسائلك مع إدارة المنصة", href: "/dashboard/customer/messages" },
    { title: "الإشعارات", desc: `${unreadCount ?? 0} إشعار غير مقروء`, href: "/dashboard/customer/notifications" },
  ];

  return (
    <div>
      <h1 className="mb-6 text-2xl font-bold text-gray-800">مرحبًا، {profile?.name} 👋</h1>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => (
          <Link key={c.title} href={c.href} className="rounded-xl border bg-white p-5 shadow-sm transition hover:shadow-md">
            <h3 className="mb-1 font-semibold text-primary">{c.title}</h3>
            <p className="text-sm text-gray-500">{c.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
