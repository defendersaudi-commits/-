import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { PropertyWithImages } from "@/lib/types";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import PropertyCard from "@/components/PropertyCard";
import HeroSearchBox from "@/components/HeroSearchBox";

export const revalidate = 60;

export default async function HomePage() {
  const supabase = createClient();

  const { data: featured } = await supabase
    .from("properties")
    .select("*, property_images(*)")
    .eq("featured", true)
    .neq("status", "sold")
    .order("created_at", { ascending: false })
    .limit(6);

  const { data: latest } = await supabase
    .from("properties")
    .select("*, property_images(*)")
    .order("created_at", { ascending: false })
    .limit(8);

  const categories = [
    { label: "فلل", type: "villa", emoji: "🏡" },
    { label: "شقق", type: "apartment", emoji: "🏢" },
    { label: "أراضٍ", type: "land", emoji: "🗺️" },
    { label: "عقارات تجارية", type: "commercial", emoji: "🏬" },
  ];

  return (
    <>
      <SiteHeader />

      {/* Hero */}
      <section className="bg-gradient-to-b from-primary to-primary-dark px-4 pb-24 pt-16 text-center text-white sm:px-6">
        <h1 className="mb-3 text-3xl font-bold sm:text-4xl">
          المفتاح العقاري — مفتاحك لعقارك القادم
        </h1>
        <p className="mx-auto mb-10 max-w-xl text-white/80">
          اكتشف العقارات المناسبة لك بسهولة، وابحث عن منزلك أو استثمارك القادم.
        </p>
        <HeroSearchBox />
      </section>

      {/* Categories */}
      <section className="mx-auto -mt-10 max-w-6xl px-4 sm:px-6">
        <div className="grid grid-cols-2 gap-4 rounded-2xl bg-white p-4 shadow-lg sm:grid-cols-4">
          {categories.map((c) => (
            <Link
              key={c.type}
              href={`/properties?property_type=${c.type}`}
              className="flex flex-col items-center gap-2 rounded-xl p-4 text-center transition hover:bg-gray-50"
            >
              <span className="text-3xl">{c.emoji}</span>
              <span className="font-semibold text-gray-700">{c.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured properties */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-800">عقارات مميزة</h2>
          <Link href="/properties" className="text-sm font-semibold text-primary">
            عرض الكل ←
          </Link>
        </div>
        {featured && featured.length > 0 ? (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {(featured as PropertyWithImages[]).map((p) => (
              <PropertyCard key={p.id} property={p} />
            ))}
          </div>
        ) : (
          <p className="text-gray-400">لا توجد عقارات مميزة حاليًا.</p>
        )}
      </section>

      {/* Latest properties */}
      <section className="bg-gray-50 py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mb-6 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-800">أحدث العقارات</h2>
            <Link href="/properties" className="text-sm font-semibold text-primary">
              عرض الكل ←
            </Link>
          </div>
          {latest && latest.length > 0 ? (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {(latest as PropertyWithImages[]).map((p) => (
                <PropertyCard key={p.id} property={p} />
              ))}
            </div>
          ) : (
            <p className="text-gray-400">لا توجد عقارات مضافة بعد.</p>
          )}
        </div>
      </section>

      <SiteFooter />
    </>
  );
}
