import Link from "next/link";

export default function UnauthorizedPage({
  searchParams,
}: {
  searchParams: { reason?: string };
}) {
  const disabled = searchParams.reason === "disabled";

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-gray-50 px-4 text-center">
      <h1 className="text-3xl font-bold text-red-600">
        {disabled ? "الحساب معطّل" : "غير مصرح لك بالوصول"}
      </h1>
      <p className="max-w-md text-gray-600">
        {disabled
          ? "تم تعطيل هذا الحساب من قبل إدارة المنصة. تواصل معنا إذا كنت تظن أن هذا خطأ."
          : "لا تملك الصلاحية اللازمة لعرض هذه الصفحة."}
      </p>
      <Link href="/" className="btn-primary max-w-xs">
        العودة للصفحة الرئيسية
      </Link>
    </main>
  );
}
