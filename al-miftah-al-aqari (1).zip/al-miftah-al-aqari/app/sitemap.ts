import type { MetadataRoute } from "next";
import { createClient } from "@/lib/supabase/server";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const supabase = createClient();

  const { data: properties } = await supabase
    .from("properties")
    .select("id, updated_at")
    .neq("status", "unavailable");

  const propertyUrls: MetadataRoute.Sitemap =
    properties?.map((p) => ({
      url: `${baseUrl}/properties/${p.id}`,
      lastModified: p.updated_at,
      changeFrequency: "daily",
      priority: 0.8,
    })) ?? [];

  return [
    { url: baseUrl, lastModified: new Date(), changeFrequency: "daily", priority: 1 },
    { url: `${baseUrl}/properties`, lastModified: new Date(), changeFrequency: "hourly", priority: 0.9 },
    ...propertyUrls,
  ];
}
