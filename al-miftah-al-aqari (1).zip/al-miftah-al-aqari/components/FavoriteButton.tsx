"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function FavoriteButton({ propertyId }: { propertyId: string }) {
  const supabase = createClient();
  const router = useRouter();
  const [isFavorite, setIsFavorite] = useState(false);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      setUserId(user?.id ?? null);

      if (user) {
        const { data } = await supabase
          .from("favorites")
          .select("id")
          .eq("user_id", user.id)
          .eq("property_id", propertyId)
          .maybeSingle();
        setIsFavorite(!!data);
      }
      setLoading(false);
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [propertyId]);

  async function toggle() {
    if (!userId) {
      router.push(`/login?redirect=/properties/${propertyId}`);
      return;
    }
    setLoading(true);
    if (isFavorite) {
      await supabase
        .from("favorites")
        .delete()
        .eq("user_id", userId)
        .eq("property_id", propertyId);
      setIsFavorite(false);
    } else {
      await supabase.from("favorites").insert({ user_id: userId, property_id: propertyId });
      setIsFavorite(true);
    }
    setLoading(false);
  }

  return (
    <button
      onClick={toggle}
      disabled={loading}
      className={`flex items-center gap-2 rounded-lg border px-4 py-2.5 font-semibold transition ${
        isFavorite
          ? "border-red-300 bg-red-50 text-red-600"
          : "border-gray-300 text-gray-600 hover:bg-gray-50"
      }`}
    >
      {isFavorite ? "♥ في المفضلة" : "♡ أضف للمفضلة"}
    </button>
  );
}
