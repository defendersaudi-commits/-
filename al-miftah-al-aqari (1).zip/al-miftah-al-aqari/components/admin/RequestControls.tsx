"use client";

import { useState, useTransition } from "react";
import { updateRequestStatus, updateRequestNotes } from "@/lib/actions/requests";

export default function RequestControls({
  requestId,
  currentStatus,
  currentNotes,
}: {
  requestId: string;
  currentStatus: string;
  currentNotes: string;
}) {
  const [notes, setNotes] = useState(currentNotes);
  const [isPending, startTransition] = useTransition();
  const [saved, setSaved] = useState(false);

  return (
    <div className="space-y-4 rounded-2xl border bg-white p-6">
      <div>
        <label className="mb-1 block text-sm text-gray-600">حالة الطلب</label>
        <select
          defaultValue={currentStatus}
          disabled={isPending}
          onChange={(e) => startTransition(() => updateRequestStatus(requestId, e.target.value))}
          className="input-field"
        >
          <option value="new">جديد</option>
          <option value="in_review">قيد المراجعة</option>
          <option value="contacted">تم التواصل</option>
          <option value="completed">مكتمل</option>
          <option value="closed">مغلق</option>
        </select>
        <p className="mt-1 text-xs text-gray-400">سيتم إشعار العميل تلقائيًا بأي تغيير.</p>
      </div>

      <div>
        <label className="mb-1 block text-sm text-gray-600">ملاحظات داخلية (لا يراها العميل)</label>
        <textarea
          value={notes}
          onChange={(e) => { setNotes(e.target.value); setSaved(false); }}
          rows={4}
          className="input-field"
        />
        <button
          onClick={() => startTransition(async () => { await updateRequestNotes(requestId, notes); setSaved(true); })}
          disabled={isPending}
          className="btn-primary mt-2"
        >
          {saved ? "تم الحفظ ✓" : "حفظ الملاحظات"}
        </button>
      </div>
    </div>
  );
}
