"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { updateCustomerStatus, deleteCustomer, setUserRole } from "@/lib/actions/customers";
import type { Profile } from "@/lib/types";

export default function CustomerActions({
  customer,
  isOwnerViewing,
}: {
  customer: Profile;
  isOwnerViewing: boolean;
}) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  return (
    <div className="flex flex-wrap gap-2">
      {customer.role !== "owner" && (
        <button
          onClick={() =>
            startTransition(() =>
              updateCustomerStatus(customer.id, customer.status === "active" ? "disabled" : "active")
            )
          }
          disabled={isPending}
          className={`rounded-lg px-4 py-2 text-sm font-semibold ${
            customer.status === "active" ? "bg-red-50 text-red-600" : "bg-green-50 text-green-700"
          }`}
        >
          {customer.status === "active" ? "تعطيل الحساب" : "إعادة التفعيل"}
        </button>
      )}

      {isOwnerViewing && customer.role !== "owner" && (
        <button
          onClick={() =>
            startTransition(() => setUserRole(customer.id, customer.role === "admin" ? "customer" : "admin"))
          }
          disabled={isPending}
          className="rounded-lg bg-primary/10 px-4 py-2 text-sm font-semibold text-primary"
        >
          {customer.role === "admin" ? "تخفيض إلى عميل" : "ترقية إلى مدير"}
        </button>
      )}

      {customer.role !== "owner" && (
        <button
          onClick={() => {
            if (confirm("هل أنت متأكد من حذف هذا الحساب نهائيًا؟")) {
              startTransition(async () => {
                await deleteCustomer(customer.id);
                router.push("/dashboard/admin/customers");
              });
            }
          }}
          disabled={isPending}
          className="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white"
        >
          حذف الحساب
        </button>
      )}
    </div>
  );
}
