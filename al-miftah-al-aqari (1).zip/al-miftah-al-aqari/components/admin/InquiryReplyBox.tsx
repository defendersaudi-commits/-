"use client";

import { useState, useTransition } from "react";
import { replyToInquiry } from "@/lib/actions/messages";

export default function InquiryReplyBox({ inquiryId, existingReply }: { inquiryId: string; existingReply: string | null }) {
  const [reply, setReply] = useState(existingReply ?? "");
  const [isPending, startTransition] = useTransition();
  const [sent, setSent] = useState(false);

  if (existingReply && !sent) {
    return (
      <div className="rounded-lg bg-green-50 p-3 text-sm text-green-700">
        <p className="mb-1 font-semibold">تم الرد:</p>
        <p>{existingReply}</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <textarea
        value={reply}
        onChange={(e) => setReply(e.target.value)}
        rows={2}
        placeholder="اكتب ردًا على العميل..."
        className="input-field"
      />
      <button
        onClick={() => startTransition(async () => { await replyToInquiry(inquiryId, reply); setSent(true); })}
        disabled={isPending || !reply}
        className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
      >
        {isPending ? "جارٍ الإرسال..." : "إرسال الرد"}
      </button>
    </div>
  );
}
