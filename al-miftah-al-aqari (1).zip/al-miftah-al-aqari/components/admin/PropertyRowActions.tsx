"use client";

import { useTransition } from "react";
import { deleteProperty, toggleFeatured, changePropertyStatus } from "@/lib/actions/properties";
import type { Property } from "@/lib/types";

export default function PropertyRowActions({ property }: { property: Property }) {
  const [isPending, startTransition] = useTransition();

  return (
    <div className="flex flex-wrap items-center gap-2 text-xs">
      <button
        onClick={() => startTransition(() => toggleFeatured(property.id, !property.featured))}
        disabled={isPending}
        className={`rounded-full px-3 py-1 font-semibold ${
          property.featured ? "bg-gold text-white" : "bg-gray-100 text-gray-600"
        }`}
      >
        {property.featured ? "★ مميز" : "☆ اجعله مميزًا"}
      </button>

      <select
        defaultValue={property.status}
        disabled={isPending}
        onChange={(e) => startTransition(() => changePropertyStatus(property.id, e.target.value))}
        className="rounded-full border px-2 py-1 text-xs"
      >
        <option value="available">متاح</option>
        <option value="sold">مباع</option>
        <option value="rented">مؤجر</option>
        <option value="reserved">محجوز</option>
        <option value="unavailable">غير متاح</option>
      </select>

      <button
        onClick={() => {
          if (confirm("هل أنت متأكد من حذف هذا العقار؟ لا يمكن التراجع.")) {
            startTransition(() => deleteProperty(property.id));
          }
        }}
        disabled={isPending}
        className="rounded-full bg-red-50 px-3 py-1 font-semibold text-red-600"
      >
        حذف
      </button>
    </div>
  );
}
