import Link from "next/link";
import Image from "next/image";
import {
  PropertyWithImages,
  PROPERTY_TYPE_LABELS,
  TRANSACTION_TYPE_LABELS,
  PROPERTY_STATUS_LABELS,
} from "@/lib/types";

function formatPrice(price: number) {
  return new Intl.NumberFormat("ar-SA").format(price);
}

export default function PropertyCard({ property }: { property: PropertyWithImages }) {
  const primaryImage =
    property.property_images?.find((img) => img.is_primary)?.image_url ??
    property.property_images?.[0]?.image_url ??
    "https://picsum.photos/seed/placeholder/900/600";

  const statusStyles: Record<string, string> = {
    available: "bg-green-100 text-green-700",
    sold: "bg-gray-200 text-gray-600",
    rented: "bg-blue-100 text-blue-700",
    reserved: "bg-amber-100 text-amber-700",
    unavailable: "bg-red-100 text-red-700",
  };

  return (
    <Link
      href={`/properties/${property.id}`}
      className="group block overflow-hidden rounded-2xl border bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
    >
      <div className="relative h-48 w-full overflow-hidden bg-gray-100">
        <Image
          src={primaryImage}
          alt={property.title}
          fill
          className="object-cover transition group-hover:scale-105"
          unoptimized
        />
        {property.featured && (
          <span className="absolute right-3 top-3 rounded-full bg-gold px-3 py-1 text-xs font-bold text-white">
            مميز
          </span>
        )}
        <span
          className={`absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-semibold ${statusStyles[property.status]}`}
        >
          {PROPERTY_STATUS_LABELS[property.status]}
        </span>
      </div>

      <div className="p-4">
        <h3 className="mb-1 truncate font-bold text-gray-800">{property.title}</h3>
        <p className="mb-3 text-sm text-gray-500">
          {property.city}
          {property.district ? ` · ${property.district}` : ""}
        </p>

        <div className="mb-3 flex flex-wrap gap-2 text-xs text-gray-500">
          <span className="rounded-full bg-gray-100 px-2 py-1">
            {PROPERTY_TYPE_LABELS[property.property_type]}
          </span>
          <span className="rounded-full bg-gray-100 px-2 py-1">
            {TRANSACTION_TYPE_LABELS[property.transaction_type]}
          </span>
          {property.area && (
            <span className="rounded-full bg-gray-100 px-2 py-1">{property.area} م²</span>
          )}
          {property.bedrooms != null && (
            <span className="rounded-full bg-gray-100 px-2 py-1">{property.bedrooms} غرف</span>
          )}
        </div>

        <p className="text-lg font-bold text-primary">
          {formatPrice(property.price)} ريال
          {property.transaction_type === "rent" && (
            <span className="text-sm font-normal text-gray-400"> / سنويًا</span>
          )}
        </p>
      </div>
    </Link>
  );
}
