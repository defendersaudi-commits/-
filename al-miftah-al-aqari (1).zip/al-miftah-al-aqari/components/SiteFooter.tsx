import Link from "next/link";

export default function SiteFooter() {
  return (
    <footer id="contact" className="mt-16 bg-primary-dark text-white/90">
      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-8 px-6 py-12 sm:grid-cols-3">
        <div>
          <h3 className="mb-3 text-lg font-bold text-white">المفتاح العقاري</h3>
          <p className="text-sm text-white/70">
            منصتك لبيع وشراء وتأجير الفلل والشقق والأراضي والعقارات التجارية
            في المملكة العربية السعودية.
          </p>
        </div>

        <div>
          <h4 className="mb-3 font-semibold text-white">روابط سريعة</h4>
          <ul className="space-y-2 text-sm text-white/70">
            <li><Link href="/properties" className="hover:text-white">جميع العقارات</Link></li>
            <li><Link href="/register" className="hover:text-white">إنشاء حساب</Link></li>
            <li><Link href="/login" className="hover:text-white">تسجيل الدخول</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="mb-3 font-semibold text-white">تواصل معنا</h4>
          <ul className="space-y-2 text-sm text-white/70">
            <li>
              <a href="tel:0556407465" className="hover:text-white" dir="ltr">
                📞 0556407465
              </a>
            </li>
            <li>
              <a href="mailto:defendersaudi@gmail.com" className="hover:text-white">
                ✉️ defendersaudi@gmail.com
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-white/50">
        © {new Date().getFullYear()} المفتاح العقاري. جميع الحقوق محفوظة.
      </div>
    </footer>
  );
}
