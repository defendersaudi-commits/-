"use client";

import { useState, useEffect } from "react";
import { createClient } from "@/lib/supabase/client";

export default function InquiryForm({ propertyId }: { propertyId: string }) {
  const supabase = createClient();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("أرغب في مزيد من المعلومات عن هذا العقار.");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function prefill() {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data: profile } = await supabase
          .from("profiles")
          .select("name, phone, email")
          .eq("id", user.id)
          .single();
        if (profile) {
          setName(profile.name ?? "");
          setPhone(profile.phone ?? "");
          setEmail(profile.email ?? "");
        }
      }
    }
    prefill();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { data: { user } } = await supabase.auth.getUser();

    const { error: insertError } = await supabase.from("inquiries").insert({
      property_id: propertyId,
      user_id: user?.id ?? null,
      name,
      phone,
      email,
      message,
    });

    setLoading(false);
    if (insertError) {
      setError("تعذّر إرسال الاستفسار، حاول مرة أخرى");
      return;
    }
    setSent(true);
  }

  if (sent) {
    return (
      <div className="rounded-lg bg-green-50 p-4 text-center text-green-700">
        تم إرسال استفسارك بنجاح ✅ سيتواصل معك فريقنا قريبًا.
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3 rounded-2xl border bg-white p-5">
      <h3 className="font-bold text-gray-800">استفسر عن هذا العقار</h3>
      <input className="input-field" placeholder="الاسم" required value={name} onChange={(e) => setName(e.target.value)} />
      <input className="input-field" placeholder="رقم الجوال" required value={phone} onChange={(e) => setPhone(e.target.value)} />
      <input className="input-field" type="email" placeholder="البريد الإلكتروني" value={email} onChange={(e) => setEmail(e.target.value)} />
      <textarea className="input-field" rows={3} required value={message} onChange={(e) => setMessage(e.target.value)} />
      {error && <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>}
      <button className="btn-primary" disabled={loading}>
        {loading ? "جارٍ الإرسال..." : "إرسال الاستفسار"}
      </button>
    </form>
  );
}
