"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { addPropertyImage, deletePropertyImage } from "@/lib/actions/properties";
import type { PropertyImage } from "@/lib/types";

export default function PropertyImageManager({
  propertyId,
  images,
}: {
  propertyId: string;
  images: PropertyImage[];
}) {
  const supabase = createClient();
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setError("حجم الصورة يجب ألا يتجاوز 5 ميجابايت");
      return;
    }

    setUploading(true);
    setError(null);

    const fileExt = file.name.split(".").pop();
    const fileName = `${propertyId}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("property-images")
      .upload(fileName, file);

    if (uploadError) {
      setUploading(false);
      setError("تعذّر رفع الصورة: " + uploadError.message);
      return;
    }

    const {
      data: { publicUrl },
    } = supabase.storage.from("property-images").getPublicUrl(fileName);

    await addPropertyImage(propertyId, publicUrl, images.length === 0);
    setUploading(false);
    e.target.value = "";
  }

  return (
    <div className="rounded-2xl border bg-white p-5">
      <h3 className="mb-3 font-bold text-gray-800">صور العقار</h3>

      <div className="mb-4 grid grid-cols-3 gap-3 sm:grid-cols-4">
        {images.map((img) => (
          <div key={img.id} className="group relative aspect-video overflow-hidden rounded-lg border">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img.image_url} alt="" className="h-full w-full object-cover" />
            {img.is_primary && (
              <span className="absolute right-1 top-1 rounded bg-gold px-1.5 py-0.5 text-[10px] font-bold text-white">
                رئيسية
              </span>
            )}
            <button
              type="button"
              onClick={() => deletePropertyImage(img.id, propertyId)}
              className="absolute inset-0 flex items-center justify-center bg-black/50 text-white opacity-0 transition group-hover:opacity-100"
            >
              حذف
            </button>
          </div>
        ))}
      </div>

      <label className="block cursor-pointer rounded-lg border-2 border-dashed border-gray-300 p-4 text-center text-sm text-gray-500 hover:border-primary hover:text-primary">
        {uploading ? "جارٍ الرفع..." : "اضغط لرفع صورة جديدة (JPG/PNG/WebP، حتى 5 ميجابايت)"}
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
          onChange={handleUpload}
          disabled={uploading}
        />
      </label>
      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
    </div>
  );
}
