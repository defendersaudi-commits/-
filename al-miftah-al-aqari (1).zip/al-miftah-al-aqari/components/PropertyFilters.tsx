"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useState } from "react";

export default function PropertyFilters() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const [q, setQ] = useState(searchParams.get("q") ?? "");
  const [city, setCity] = useState(searchParams.get("city") ?? "");
  const [district, setDistrict] = useState(searchParams.get("district") ?? "");
  const [propertyType, setPropertyType] = useState(searchParams.get("property_type") ?? "");
  const [transactionType, setTransactionType] = useState(searchParams.get("transaction_type") ?? "");
  const [minPrice, setMinPrice] = useState(searchParams.get("min_price") ?? "");
  const [maxPrice, setMaxPrice] = useState(searchParams.get("max_price") ?? "");
  const [minArea, setMinArea] = useState(searchParams.get("min_area") ?? "");
  const [bedrooms, setBedrooms] = useState(searchParams.get("bedrooms") ?? "");
  const [bathrooms, setBathrooms] = useState(searchParams.get("bathrooms") ?? "");
  const [sort, setSort] = useState(searchParams.get("sort") ?? "newest");

  function apply(e?: React.FormEvent) {
    e?.preventDefault();
    const params = new URLSearchParams();
    const set = (key: string, val: string) => val && params.set(key, val);
    set("q", q);
    set("city", city);
    set("district", district);
    set("property_type", propertyType);
    set("transaction_type", transactionType);
    set("min_price", minPrice);
    set("max_price", maxPrice);
    set("min_area", minArea);
    set("bedrooms", bedrooms);
    set("bathrooms", bathrooms);
    set("sort", sort);
    router.push(`${pathname}?${params.toString()}`);
  }

  function reset() {
    setQ(""); setCity(""); setDistrict(""); setPropertyType("");
    setTransactionType(""); setMinPrice(""); setMaxPrice("");
    setMinArea(""); setBedrooms(""); setBathrooms(""); setSort("newest");
    router.push(pathname);
  }

  return (
    <form onSubmit={apply} className="space-y-4 rounded-2xl border bg-white p-5">
      <div>
        <label className="mb-1 block text-sm text-gray-600">كلمة البحث</label>
        <input className="input-field" value={q} onChange={(e) => setQ(e.target.value)} placeholder="اسم العقار أو الوصف" />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1 block text-sm text-gray-600">المدينة</label>
          <input className="input-field" value={city} onChange={(e) => setCity(e.target.value)} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">الحي</label>
          <input className="input-field" value={district} onChange={(e) => setDistrict(e.target.value)} />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-gray-600">نوع العقار</label>
        <select className="input-field" value={propertyType} onChange={(e) => setPropertyType(e.target.value)}>
          <option value="">الكل</option>
          <option value="villa">فيلا</option>
          <option value="apartment">شقة</option>
          <option value="land">أرض</option>
          <option value="building">عمارة</option>
          <option value="residential">سكني</option>
          <option value="commercial">تجاري</option>
        </select>
      </div>

      <div>
        <label className="mb-1 block text-sm text-gray-600">نوع المعاملة</label>
        <select className="input-field" value={transactionType} onChange={(e) => setTransactionType(e.target.value)}>
          <option value="">بيع / إيجار</option>
          <option value="sale">للبيع</option>
          <option value="rent">للإيجار</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1 block text-sm text-gray-600">أقل سعر</label>
          <input type="number" className="input-field" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">أعلى سعر</label>
          <input type="number" className="input-field" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-gray-600">أقل مساحة (م²)</label>
        <input type="number" className="input-field" value={minArea} onChange={(e) => setMinArea(e.target.value)} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="mb-1 block text-sm text-gray-600">عدد الغرف</label>
          <input type="number" className="input-field" value={bedrooms} onChange={(e) => setBedrooms(e.target.value)} />
        </div>
        <div>
          <label className="mb-1 block text-sm text-gray-600">دورات المياه</label>
          <input type="number" className="input-field" value={bathrooms} onChange={(e) => setBathrooms(e.target.value)} />
        </div>
      </div>

      <div>
        <label className="mb-1 block text-sm text-gray-600">الترتيب حسب</label>
        <select className="input-field" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="newest">الأحدث</option>
          <option value="price_asc">السعر: من الأقل للأعلى</option>
          <option value="price_desc">السعر: من الأعلى للأقل</option>
          <option value="featured">العقارات المميزة</option>
        </select>
      </div>

      <div className="flex gap-2">
        <button type="submit" className="btn-primary">تطبيق الفلاتر</button>
        <button type="button" onClick={reset} className="w-full rounded-lg border px-4 py-2.5 font-semibold text-gray-600 hover:bg-gray-50">
          إعادة تعيين
        </button>
      </div>
    </form>
  );
}
