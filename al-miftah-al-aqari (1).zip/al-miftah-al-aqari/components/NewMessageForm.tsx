"use client";

import { useState, useTransition } from "react";
import { sendMessageToAdmin } from "@/lib/actions/customer";

export default function NewMessageForm() {
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();
  const [sent, setSent] = useState(false);

  return (
    <div className="space-y-3 rounded-2xl border bg-white p-5">
      <h3 className="font-bold text-gray-800">راسل إدارة المنصة</h3>
      <input className="input-field" placeholder="الموضوع" value={subject} onChange={(e) => setSubject(e.target.value)} />
      <textarea className="input-field" rows={3} placeholder="رسالتك..." value={message} onChange={(e) => setMessage(e.target.value)} />
      <button
        onClick={() =>
          startTransition(async () => {
            await sendMessageToAdmin(subject, message);
            setSubject(""); setMessage(""); setSent(true);
            setTimeout(() => setSent(false), 3000);
          })
        }
        disabled={isPending || !message}
        className="btn-primary"
      >
        {isPending ? "جارٍ الإرسال..." : sent ? "تم الإرسال ✓" : "إرسال"}
      </button>
    </div>
  );
}
