"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function HeroSearchBox() {
  const router = useRouter();
  const [transactionType, setTransactionType] = useState("");
  const [propertyType, setPropertyType] = useState("");
  const [city, setCity] = useState("");
  const [keyword, setKeyword] = useState("");

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (keyword) params.set("q", keyword);
    if (transactionType) params.set("transaction_type", transactionType);
    if (propertyType) params.set("property_type", propertyType);
    if (city) params.set("city", city);
    router.push(`/properties?${params.toString()}`);
  }

  return (
    <form
      onSubmit={handleSearch}
      className="mx-auto grid w-full max-w-4xl grid-cols-1 gap-3 rounded-2xl bg-white p-4 shadow-xl sm:grid-cols-5"
    >
      <input
        className="input-field sm:col-span-2"
        placeholder="ابحث عن عقار، حي، أو مدينة..."
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
      />
      <select
        className="input-field"
        value={transactionType}
        onChange={(e) => setTransactionType(e.target.value)}
      >
        <option value="">بيع / إيجار</option>
        <option value="sale">للبيع</option>
        <option value="rent">للإيجار</option>
      </select>
      <select
        className="input-field"
        value={propertyType}
        onChange={(e) => setPropertyType(e.target.value)}
      >
        <option value="">نوع العقار</option>
        <option value="villa">فيلا</option>
        <option value="apartment">شقة</option>
        <option value="land">أرض</option>
        <option value="building">عمارة</option>
        <option value="commercial">تجاري</option>
      </select>
      <button type="submit" className="btn-primary sm:col-span-1">
        بحث
      </button>
    </form>
  );
}
