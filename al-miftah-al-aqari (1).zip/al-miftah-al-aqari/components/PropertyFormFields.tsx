import type { Property } from "@/lib/types";

export default function PropertyFormFields({ property }: { property?: Property }) {
  return (
    <>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className="mb-1 block text-sm text-gray-600">عنوان العقار *</label>
          <input name="title" required defaultValue={property?.title} className="input-field" />
        </div>

        <div className="sm:col-span-2">
          <label className="mb-1 block text-sm text-gray-600">الوصف الكامل</label>
          <textarea name="description" rows={4} defaultValue={property?.description ?? ""} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">نوع العقار *</label>
          <select name="property_type" required defaultValue={property?.property_type ?? "villa"} className="input-field">
            <option value="villa">فيلا</option>
            <option value="apartment">شقة</option>
            <option value="land">أرض</option>
            <option value="building">عمارة</option>
            <option value="residential">سكني</option>
            <option value="commercial">تجاري</option>
          </select>
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">نوع المعاملة *</label>
          <select name="transaction_type" required defaultValue={property?.transaction_type ?? "sale"} className="input-field">
            <option value="sale">للبيع</option>
            <option value="rent">للإيجار</option>
          </select>
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">السعر (ريال) *</label>
          <input type="number" step="0.01" name="price" required defaultValue={property?.price} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">المساحة (م²)</label>
          <input type="number" step="0.01" name="area" defaultValue={property?.area ?? ""} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">المدينة *</label>
          <input name="city" required defaultValue={property?.city} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">الحي</label>
          <input name="district" defaultValue={property?.district ?? ""} className="input-field" />
        </div>

        <div className="sm:col-span-2">
          <label className="mb-1 block text-sm text-gray-600">العنوان التفصيلي</label>
          <input name="address" defaultValue={property?.address ?? ""} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">عدد غرف النوم</label>
          <input type="number" name="bedrooms" defaultValue={property?.bedrooms ?? ""} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">عدد دورات المياه</label>
          <input type="number" name="bathrooms" defaultValue={property?.bathrooms ?? ""} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">خط العرض (Latitude)</label>
          <input type="number" step="any" name="latitude" defaultValue={property?.latitude ?? ""} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">خط الطول (Longitude)</label>
          <input type="number" step="any" name="longitude" defaultValue={property?.longitude ?? ""} className="input-field" />
        </div>

        <div>
          <label className="mb-1 block text-sm text-gray-600">حالة العقار</label>
          <select name="status" defaultValue={property?.status ?? "available"} className="input-field">
            <option value="available">متاح</option>
            <option value="sold">مباع</option>
            <option value="rented">مؤجر</option>
            <option value="reserved">محجوز</option>
            <option value="unavailable">غير متاح</option>
          </select>
        </div>

        <div className="flex items-center gap-2 pt-6">
          <input type="checkbox" id="featured" name="featured" defaultChecked={property?.featured} className="h-4 w-4" />
          <label htmlFor="featured" className="text-sm text-gray-700">عقار مميز (يظهر في الصفحة الرئيسية)</label>
        </div>
      </div>
    </>
  );
}
