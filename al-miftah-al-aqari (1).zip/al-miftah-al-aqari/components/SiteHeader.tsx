import Link from "next/link";
import { getCurrentProfile } from "@/lib/supabase/server";

export default async function SiteHeader() {
  const profile = await getCurrentProfile();

  const dashboardHref =
    profile?.role === "owner" || profile?.role === "admin"
      ? "/dashboard/admin"
      : "/dashboard/customer";

  return (
    <header className="sticky top-0 z-40 border-b bg-white/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2 text-xl font-bold text-primary">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-white">
            🔑
          </span>
          المفتاح العقاري
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-medium text-gray-600 md:flex">
          <Link href="/properties" className="hover:text-primary">جميع العقارات</Link>
          <Link href="/properties?property_type=villa" className="hover:text-primary">فلل</Link>
          <Link href="/properties?property_type=apartment" className="hover:text-primary">شقق</Link>
          <Link href="/properties?property_type=land" className="hover:text-primary">أراضٍ</Link>
          <Link href="/properties?property_type=commercial" className="hover:text-primary">تجاري</Link>
          <Link href="/#contact" className="hover:text-primary">تواصل معنا</Link>
        </nav>

        <div className="flex items-center gap-3">
          {profile ? (
            <Link
              href={dashboardHref}
              className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white hover:bg-primary-dark"
            >
              لوحتي
            </Link>
          ) : (
            <>
              <Link
                href="/login"
                className="hidden text-sm font-semibold text-primary sm:block"
              >
                تسجيل الدخول
              </Link>
              <Link
                href="/register"
                className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-white hover:bg-primary-dark"
              >
                إنشاء حساب
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
