import { NextResponse, type NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";

export async function middleware(request: NextRequest) {
  const { supabaseResponse, user, profile } = await updateSession(request);
  const path = request.nextUrl.pathname;

  const isAuthRoute =
    path.startsWith("/login") ||
    path.startsWith("/register") ||
    path.startsWith("/forgot-password") ||
    path.startsWith("/reset-password");

  const isAdminRoute = path.startsWith("/dashboard/admin");
  const isCustomerRoute = path.startsWith("/dashboard/customer");

  // غير مسجل دخول ويحاول يدخل صفحة محمية → إلى تسجيل الدخول
  if (!user && (isAdminRoute || isCustomerRoute)) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("redirect", path);
    return NextResponse.redirect(url);
  }

  // مسجل دخول ويحاول يدخل صفحات تسجيل الدخول/التسجيل → حوّله للوحته
  if (user && isAuthRoute) {
    const url = request.nextUrl.clone();
    url.pathname =
      profile?.role === "owner" || profile?.role === "admin"
        ? "/dashboard/admin"
        : "/dashboard/customer";
    return NextResponse.redirect(url);
  }

  // فحص الصلاحية الفعلي على الخادم — هذا هو خط الدفاع الحقيقي، لا يعتمد على الواجهة
  if (isAdminRoute && profile?.role !== "owner" && profile?.role !== "admin") {
    const url = request.nextUrl.clone();
    url.pathname = "/unauthorized";
    return NextResponse.redirect(url);
  }

  // حساب معطّل → منع الدخول لأي صفحة محمية
  if ((isAdminRoute || isCustomerRoute) && profile?.status === "disabled") {
    const url = request.nextUrl.clone();
    url.pathname = "/unauthorized";
    url.searchParams.set("reason", "disabled");
    return NextResponse.redirect(url);
  }

  return supabaseResponse;
}

export const config = {
  matcher: [
    "/dashboard/:path*",
    "/login",
    "/register",
    "/forgot-password",
    "/reset-password",
  ],
};
