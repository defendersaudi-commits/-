"use server";

import { revalidatePath } from "next/cache";
import { createClient, getCurrentProfile } from "@/lib/supabase/server";

async function requireAdmin() {
  const profile = await getCurrentProfile();
  if (!profile || (profile.role !== "owner" && profile.role !== "admin")) {
    throw new Error("غير مصرح");
  }
  return profile;
}

async function requireOwner() {
  const profile = await getCurrentProfile();
  if (!profile || profile.role !== "owner") {
    throw new Error("هذا الإجراء متاح لمالك المنصة فقط");
  }
  return profile;
}

async function logActivity(action: string, details: Record<string, unknown>) {
  const supabase = createClient();
  const profile = await getCurrentProfile();
  await supabase.from("admin_activity_log").insert({
    admin_id: profile?.id,
    action,
    details,
  });
}

export async function updateCustomerStatus(customerId: string, status: "active" | "disabled") {
  await requireAdmin();
  const supabase = createClient();
  const { error } = await supabase
    .from("profiles")
    .update({ status } as never)
    .eq("id", customerId);

  if (error) throw new Error(error.message);
  await logActivity("update_customer_status", { customer_id: customerId, status });
  revalidatePath("/dashboard/admin/customers");
}

export async function updateCustomerInfo(customerId: string, formData: FormData) {
  await requireAdmin();
  const supabase = createClient();
  const payload = {
    name: String(formData.get("name")),
    phone: String(formData.get("phone") ?? "") || null,
  };
  const { error } = await supabase.from("profiles").update(payload as never).eq("id", customerId);
  if (error) throw new Error(error.message);
  await logActivity("update_customer_info", { customer_id: customerId });
  revalidatePath(`/dashboard/admin/customers/${customerId}`);
}

export async function deleteCustomer(customerId: string) {
  await requireAdmin();
  const supabase = createClient();
  const { error } = await supabase.from("profiles").delete().eq("id", customerId);
  if (error) throw new Error(error.message);
  await logActivity("delete_customer", { customer_id: customerId });
  revalidatePath("/dashboard/admin/customers");
}

/** ترقية/تخفيض دور مستخدم — لمالك المنصة فقط، ومحمي أيضًا بـ trigger في قاعدة البيانات */
export async function setUserRole(userId: string, role: "admin" | "customer") {
  await requireOwner();
  const supabase = createClient();
  const { error } = await supabase.from("profiles").update({ role } as never).eq("id", userId);
  if (error) throw new Error(error.message);
  await logActivity("set_user_role", { user_id: userId, role });
  revalidatePath("/dashboard/admin/customers");
  revalidatePath(`/dashboard/admin/customers/${userId}`);
}
