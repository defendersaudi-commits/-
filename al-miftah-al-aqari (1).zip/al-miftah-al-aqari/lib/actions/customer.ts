"use server";

import { revalidatePath } from "next/cache";
import { createClient, getCurrentProfile } from "@/lib/supabase/server";

async function requireUser() {
  const profile = await getCurrentProfile();
  if (!profile) throw new Error("يجب تسجيل الدخول أولاً");
  return profile;
}

export async function updateOwnProfile(formData: FormData) {
  const profile = await requireUser();
  const supabase = createClient();
  const payload = {
    name: String(formData.get("name")),
    phone: String(formData.get("phone") ?? "") || null,
  };
  const { error } = await supabase.from("profiles").update(payload as never).eq("id", profile.id);
  if (error) throw new Error(error.message);
  revalidatePath("/dashboard/customer/profile");
}

export async function createPropertyRequest(formData: FormData) {
  const profile = await requireUser();
  const supabase = createClient();

  const payload = {
    user_id: profile.id,
    request_type: String(formData.get("request_type")),
    property_type: String(formData.get("property_type") ?? "") || null,
    city: String(formData.get("city") ?? "") || null,
    district: String(formData.get("district") ?? "") || null,
    budget: formData.get("budget") ? Number(formData.get("budget")) : null,
    details: String(formData.get("details") ?? "") || null,
  };

  const { error } = await supabase.from("requests").insert(payload as never);
  if (error) throw new Error(error.message);
  revalidatePath("/dashboard/customer/requests");
}

export async function markNotificationRead(notificationId: string) {
  const profile = await requireUser();
  const supabase = createClient();
  await supabase
    .from("notifications")
    .update({ is_read: true } as never)
    .eq("id", notificationId)
    .eq("user_id", profile.id);
  revalidatePath("/dashboard/customer/notifications");
}

export async function markAllNotificationsRead() {
  const profile = await requireUser();
  const supabase = createClient();
  await supabase
    .from("notifications")
    .update({ is_read: true } as never)
    .eq("user_id", profile.id)
    .eq("is_read", false);
  revalidatePath("/dashboard/customer/notifications");
}

export async function sendMessageToAdmin(subject: string, message: string) {
  const profile = await requireUser();
  const supabase = createClient();
  const { error } = await supabase.from("messages").insert({
    sender_id: profile.id,
    receiver_id: null,
    subject,
    message,
  } as never);
  if (error) throw new Error(error.message);
  revalidatePath("/dashboard/customer/messages");
}
