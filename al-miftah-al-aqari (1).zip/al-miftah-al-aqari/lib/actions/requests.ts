"use server";

import { revalidatePath } from "next/cache";
import { createClient, getCurrentProfile } from "@/lib/supabase/server";

async function requireAdmin() {
  const profile = await getCurrentProfile();
  if (!profile || (profile.role !== "owner" && profile.role !== "admin")) {
    throw new Error("غير مصرح");
  }
  return profile;
}

async function logActivity(action: string, details: Record<string, unknown>) {
  const supabase = createClient();
  const profile = await getCurrentProfile();
  await supabase.from("admin_activity_log").insert({
    admin_id: profile?.id,
    action,
    details,
  });
}

export async function updateRequestStatus(requestId: string, status: string) {
  await requireAdmin();
  const supabase = createClient();
  const { error } = await supabase.from("requests").update({ status } as never).eq("id", requestId);
  if (error) throw new Error(error.message);
  await logActivity("update_request_status", { request_id: requestId, status });
  revalidatePath("/dashboard/admin/requests");
  revalidatePath(`/dashboard/admin/requests/${requestId}`);
}

export async function updateRequestNotes(requestId: string, notes: string) {
  await requireAdmin();
  const supabase = createClient();
  const { error } = await supabase
    .from("requests")
    .update({ admin_notes: notes } as never)
    .eq("id", requestId);
  if (error) throw new Error(error.message);
  revalidatePath(`/dashboard/admin/requests/${requestId}`);
}

export async function archiveRequest(requestId: string) {
  await requireAdmin();
  const supabase = createClient();
  await supabase.from("requests").update({ status: "closed" } as never).eq("id", requestId);
  await logActivity("archive_request", { request_id: requestId });
  revalidatePath("/dashboard/admin/requests");
}
