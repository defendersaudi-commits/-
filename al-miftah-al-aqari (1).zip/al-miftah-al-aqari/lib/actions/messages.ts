"use server";

import { revalidatePath } from "next/cache";
import { createClient, getCurrentProfile } from "@/lib/supabase/server";

async function requireAdmin() {
  const profile = await getCurrentProfile();
  if (!profile || (profile.role !== "owner" && profile.role !== "admin")) {
    throw new Error("غير مصرح");
  }
  return profile;
}

async function logActivity(action: string, details: Record<string, unknown>) {
  const supabase = createClient();
  const profile = await getCurrentProfile();
  await supabase.from("admin_activity_log").insert({
    admin_id: profile?.id,
    action,
    details,
  });
}

export async function replyToInquiry(inquiryId: string, reply: string) {
  const admin = await requireAdmin();
  const supabase = createClient();

  const { data: inquiry } = await supabase
    .from("inquiries")
    .select("user_id, property_id")
    .eq("id", inquiryId)
    .single();

  const { error } = await supabase
    .from("inquiries")
    .update({
      admin_reply: reply,
      replied_by: admin.id,
      replied_at: new Date().toISOString(),
      status: "resolved",
    } as never)
    .eq("id", inquiryId);

  if (error) throw new Error(error.message);

  // إذا كان المستفسر مستخدمًا مسجلاً، أرسل له رسالة داخلية أيضًا
  if (inquiry?.user_id) {
    await supabase.from("messages").insert({
      sender_id: admin.id,
      receiver_id: inquiry.user_id,
      subject: "رد على استفسارك",
      message: reply,
    } as never);
  }

  await logActivity("reply_to_inquiry", { inquiry_id: inquiryId });
  revalidatePath("/dashboard/admin/messages");
}

export async function updateInquiryStatus(inquiryId: string, status: string) {
  await requireAdmin();
  const supabase = createClient();
  await supabase.from("inquiries").update({ status } as never).eq("id", inquiryId);
  await logActivity("update_inquiry_status", { inquiry_id: inquiryId, status });
  revalidatePath("/dashboard/admin/messages");
}

export async function sendAdminMessage(receiverId: string, subject: string, message: string) {
  const admin = await requireAdmin();
  const supabase = createClient();
  const { error } = await supabase.from("messages").insert({
    sender_id: admin.id,
    receiver_id: receiverId,
    subject,
    message,
  } as never);
  if (error) throw new Error(error.message);
  await logActivity("send_message", { receiver_id: receiverId });
  revalidatePath("/dashboard/admin/messages");
}
