"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient, getCurrentProfile } from "@/lib/supabase/server";

async function requireAdmin() {
  const profile = await getCurrentProfile();
  if (!profile || (profile.role !== "owner" && profile.role !== "admin")) {
    throw new Error("غير مصرح");
  }
  return profile;
}

async function logActivity(action: string, details: Record<string, unknown>) {
  const supabase = createClient();
  const profile = await getCurrentProfile();
  await supabase.from("admin_activity_log").insert({
    admin_id: profile?.id,
    action,
    details,
  });
}

export async function createProperty(formData: FormData) {
  const admin = await requireAdmin();
  const supabase = createClient();

  const payload = {
    title: String(formData.get("title")),
    description: String(formData.get("description") ?? ""),
    property_type: String(formData.get("property_type")),
    transaction_type: String(formData.get("transaction_type")),
    price: Number(formData.get("price")),
    area: formData.get("area") ? Number(formData.get("area")) : null,
    city: String(formData.get("city")),
    district: String(formData.get("district") ?? "") || null,
    address: String(formData.get("address") ?? "") || null,
    bedrooms: formData.get("bedrooms") ? Number(formData.get("bedrooms")) : null,
    bathrooms: formData.get("bathrooms") ? Number(formData.get("bathrooms")) : null,
    status: String(formData.get("status") ?? "available"),
    featured: formData.get("featured") === "on",
    latitude: formData.get("latitude") ? Number(formData.get("latitude")) : null,
    longitude: formData.get("longitude") ? Number(formData.get("longitude")) : null,
    created_by: admin.id,
  };

  const { data, error } = await supabase
    .from("properties")
    .insert(payload as never)
    .select("id")
    .single();

  if (error || !data) {
    throw new Error("تعذّر إنشاء العقار: " + error?.message);
  }

  await logActivity("create_property", { property_id: data.id, title: payload.title });
  revalidatePath("/dashboard/admin/properties");
  revalidatePath("/properties");
  redirect(`/dashboard/admin/properties/${data.id}/edit`);
}

export async function updateProperty(propertyId: string, formData: FormData) {
  await requireAdmin();
  const supabase = createClient();

  const payload = {
    title: String(formData.get("title")),
    description: String(formData.get("description") ?? ""),
    property_type: String(formData.get("property_type")),
    transaction_type: String(formData.get("transaction_type")),
    price: Number(formData.get("price")),
    area: formData.get("area") ? Number(formData.get("area")) : null,
    city: String(formData.get("city")),
    district: String(formData.get("district") ?? "") || null,
    address: String(formData.get("address") ?? "") || null,
    bedrooms: formData.get("bedrooms") ? Number(formData.get("bedrooms")) : null,
    bathrooms: formData.get("bathrooms") ? Number(formData.get("bathrooms")) : null,
    status: String(formData.get("status") ?? "available"),
    featured: formData.get("featured") === "on",
    latitude: formData.get("latitude") ? Number(formData.get("latitude")) : null,
    longitude: formData.get("longitude") ? Number(formData.get("longitude")) : null,
  };

  const { error } = await supabase
    .from("properties")
    .update(payload as never)
    .eq("id", propertyId);

  if (error) throw new Error("تعذّر تحديث العقار: " + error.message);

  await logActivity("update_property", { property_id: propertyId, title: payload.title });
  revalidatePath("/dashboard/admin/properties");
  revalidatePath(`/properties/${propertyId}`);
  revalidatePath("/properties");
}

export async function deleteProperty(propertyId: string) {
  await requireAdmin();
  const supabase = createClient();

  const { error } = await supabase.from("properties").delete().eq("id", propertyId);
  if (error) throw new Error("تعذّر حذف العقار: " + error.message);

  await logActivity("delete_property", { property_id: propertyId });
  revalidatePath("/dashboard/admin/properties");
  revalidatePath("/properties");
}

export async function toggleFeatured(propertyId: string, featured: boolean) {
  await requireAdmin();
  const supabase = createClient();
  await supabase.from("properties").update({ featured } as never).eq("id", propertyId);
  await logActivity("toggle_featured", { property_id: propertyId, featured });
  revalidatePath("/dashboard/admin/properties");
  revalidatePath("/");
}

export async function changePropertyStatus(propertyId: string, status: string) {
  await requireAdmin();
  const supabase = createClient();
  await supabase.from("properties").update({ status } as never).eq("id", propertyId);
  await logActivity("change_property_status", { property_id: propertyId, status });
  revalidatePath("/dashboard/admin/properties");
  revalidatePath(`/properties/${propertyId}`);
}

export async function addPropertyImage(propertyId: string, imageUrl: string, isPrimary: boolean) {
  await requireAdmin();
  const supabase = createClient();

  if (isPrimary) {
    await supabase.from("property_images").update({ is_primary: false } as never).eq("property_id", propertyId);
  }

  const { count } = await supabase
    .from("property_images")
    .select("*", { count: "exact", head: true })
    .eq("property_id", propertyId);

  await supabase.from("property_images").insert({
    property_id: propertyId,
    image_url: imageUrl,
    sort_order: count ?? 0,
    is_primary: isPrimary || count === 0,
  } as never);

  revalidatePath(`/dashboard/admin/properties/${propertyId}/edit`);
  revalidatePath(`/properties/${propertyId}`);
}

export async function deletePropertyImage(imageId: string, propertyId: string) {
  await requireAdmin();
  const supabase = createClient();
  await supabase.from("property_images").delete().eq("id", imageId);
  revalidatePath(`/dashboard/admin/properties/${propertyId}/edit`);
  revalidatePath(`/properties/${propertyId}`);
}
