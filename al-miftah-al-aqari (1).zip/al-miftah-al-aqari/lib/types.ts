export type UserRole = "owner" | "admin" | "customer";
export type UserStatus = "active" | "disabled";
export type PropertyType =
  | "villa"
  | "apartment"
  | "land"
  | "building"
  | "residential"
  | "commercial";
export type TransactionType = "sale" | "rent";
export type PropertyStatus =
  | "available"
  | "sold"
  | "rented"
  | "reserved"
  | "unavailable";
export type RequestStatus =
  | "new"
  | "in_review"
  | "contacted"
  | "completed"
  | "closed";
export type InquiryStatus = "new" | "in_progress" | "resolved" | "archived";

export interface Profile {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  role: UserRole;
  status: UserStatus;
  created_at: string;
  updated_at: string;
}

export interface Property {
  id: string;
  title: string;
  description: string | null;
  property_type: PropertyType;
  transaction_type: TransactionType;
  price: number;
  area: number | null;
  city: string;
  district: string | null;
  address: string | null;
  bedrooms: number | null;
  bathrooms: number | null;
  status: PropertyStatus;
  featured: boolean;
  latitude: number | null;
  longitude: number | null;
  views_count: number;
  favorites_count: number;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface PropertyImage {
  id: string;
  property_id: string;
  image_url: string;
  sort_order: number;
  is_primary: boolean;
  created_at: string;
}

export interface PropertyWithImages extends Property {
  property_images: PropertyImage[];
}

export interface Favorite {
  id: string;
  user_id: string;
  property_id: string;
  created_at: string;
}

export interface Inquiry {
  id: string;
  user_id: string | null;
  property_id: string | null;
  name: string;
  phone: string | null;
  email: string | null;
  message: string;
  status: InquiryStatus;
  created_at: string;
  updated_at: string;
}

export interface PropertyRequest {
  id: string;
  user_id: string | null;
  request_type: string;
  property_type: PropertyType | null;
  city: string | null;
  district: string | null;
  budget: number | null;
  details: string | null;
  status: RequestStatus;
  admin_notes: string | null;
  created_at: string;
  updated_at: string;
}

// نوع Database مبسّط يكفي لعمل .from("...") مع استدلال أساسي
export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: Partial<Profile> & { id: string; name: string; email: string };
        Update: Partial<Profile>;
      };
      properties: {
        Row: Property;
        Insert: Partial<Property> & {
          title: string;
          property_type: PropertyType;
          transaction_type: TransactionType;
          price: number;
          city: string;
        };
        Update: Partial<Property>;
      };
      property_images: {
        Row: PropertyImage;
        Insert: Partial<PropertyImage> & {
          property_id: string;
          image_url: string;
        };
        Update: Partial<PropertyImage>;
      };
      favorites: {
        Row: Favorite;
        Insert: { user_id: string; property_id: string };
        Update: Partial<Favorite>;
      };
      inquiries: {
        Row: Inquiry;
        Insert: Partial<Inquiry> & { name: string; message: string };
        Update: Partial<Inquiry>;
      };
      requests: {
        Row: PropertyRequest;
        Insert: Partial<PropertyRequest> & { request_type: string };
        Update: Partial<PropertyRequest>;
      };
    };
  };
}

export const PROPERTY_TYPE_LABELS: Record<PropertyType, string> = {
  villa: "فيلا",
  apartment: "شقة",
  land: "أرض",
  building: "عمارة",
  residential: "سكني",
  commercial: "تجاري",
};

export const TRANSACTION_TYPE_LABELS: Record<TransactionType, string> = {
  sale: "للبيع",
  rent: "للإيجار",
};

export const PROPERTY_STATUS_LABELS: Record<PropertyStatus, string> = {
  available: "متاح",
  sold: "مباع",
  rented: "مؤجر",
  reserved: "محجوز",
  unavailable: "غير متاح",
};
